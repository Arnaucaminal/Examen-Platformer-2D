using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    private Animator anim;
    private Vector3 originalScale;

    [SerializeField] private KeyCode attackKey = KeyCode.Alpha1;
    [SerializeField] private KeyCode hurtKey = KeyCode.Alpha2;
    [SerializeField] private KeyCode dieKey = KeyCode.Alpha3;

    void Start()
    {
        anim = GetComponent<Animator>();
        originalScale = transform.localScale;
    }

    void Update()
    {
        float horizontalInput = Input.GetAxis("Horizontal");

        if (horizontalInput < 0)
        {
            // Mira cap a l'esquerra
            transform.localScale = new Vector3(-originalScale.x, originalScale.y, originalScale.z);
        }
        else if (horizontalInput > 0)
        {
            // Mira cap a la dreta
            transform.localScale = originalScale;
        }

        
        if (Input.GetKeyDown(attackKey))
        {
            anim.SetTrigger("attack");
        }
        else if (Input.GetKeyDown(hurtKey))
        {
            anim.SetTrigger("hurt");
        }
        else if (Input.GetKeyDown(dieKey))
        {
            anim.SetTrigger("die");
        }
    }
}